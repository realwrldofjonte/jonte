import React, { useState } from 'react';
import { Building, ArrowUpRight, Users, Map } from 'lucide-react';

interface SpaceType {
  id: number;
  title: string;
  size: string;
  price: string;
  type: 'office' | 'retail' | 'warehouse';
  features: string[];
  image: string;
  availability: 'Immediate' | 'Coming Soon';
}

const Spaces: React.FC = () => {
  const [filter, setFilter] = useState<'all' | 'office' | 'retail' | 'warehouse'>('all');

  const spaces: SpaceType[] = [
    {
      id: 1,
      title: 'Executive Office Suite',
      size: '150 sq.m',
      price: 'KSh 1,200/sq.m/month',
      type: 'office',
      features: ['Corner office', 'Meeting room', 'Pantry area', 'Reception space'],
      image: 'https://images.pexels.com/photos/1743555/pexels-photo-1743555.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      availability: 'Immediate',
    },
    {
      id: 2,
      title: 'Standard Office Space',
      size: '75 sq.m',
      price: 'KSh 950/sq.m/month',
      type: 'office',
      features: ['Open plan', 'Shared reception', 'High-speed internet', 'Backup power'],
      image: 'https://images.pexels.com/photos/1957477/pexels-photo-1957477.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      availability: 'Immediate',
    },
    {
      id: 3,
      title: 'Ground Floor Retail',
      size: '120 sq.m',
      price: 'KSh 1,500/sq.m/month',
      type: 'retail',
      features: ['High visibility', 'Foot traffic', 'Storage room', 'Large display windows'],
      image: 'https://images.pexels.com/photos/264507/pexels-photo-264507.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      availability: 'Coming Soon',
    },
    {
      id: 4,
      title: 'Warehouse Space',
      size: '500 sq.m',
      price: 'KSh 600/sq.m/month',
      type: 'warehouse',
      features: ['Loading bay', 'High ceiling', 'Security system', 'Easy truck access'],
      image: 'https://images.pexels.com/photos/4483608/pexels-photo-4483608.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      availability: 'Immediate',
    },
    {
      id: 5,
      title: 'Premium Corner Office',
      size: '200 sq.m',
      price: 'KSh 1,400/sq.m/month',
      type: 'office',
      features: ['Panoramic views', 'Executive washroom', 'Private entrance', 'Customizable layout'],
      image: 'https://images.pexels.com/photos/380768/pexels-photo-380768.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      availability: 'Coming Soon',
    },
    {
      id: 6,
      title: 'Food Court Space',
      size: '100 sq.m',
      price: 'KSh 1,300/sq.m/month',
      type: 'retail',
      features: ['Kitchen hood system', 'Water connections', 'Designated seating', 'Waste disposal'],
      image: 'https://images.pexels.com/photos/262978/pexels-photo-262978.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2',
      availability: 'Immediate',
    },
  ];

  const filteredSpaces = filter === 'all' 
    ? spaces 
    : spaces.filter(space => space.type === filter);

  return (
    <section id="spaces" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-8">
        <div className="max-w-3xl mx-auto text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">Available Spaces</h2>
          <div className="w-24 h-1 bg-yellow-500 mx-auto mb-6"></div>
          <p className="text-lg text-gray-700 mb-8">
            Discover the perfect space for your business with flexible options to suit your needs.
          </p>

          {/* Filter buttons */}
          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <button 
              onClick={() => setFilter('all')}
              className={`px-6 py-2 rounded-full font-medium transition-all ${
                filter === 'all' 
                  ? 'bg-blue-800 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              All Spaces
            </button>
            <button 
              onClick={() => setFilter('office')}
              className={`px-6 py-2 rounded-full font-medium transition-all ${
                filter === 'office' 
                  ? 'bg-blue-800 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Office
            </button>
            <button 
              onClick={() => setFilter('retail')}
              className={`px-6 py-2 rounded-full font-medium transition-all ${
                filter === 'retail' 
                  ? 'bg-blue-800 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Retail
            </button>
            <button 
              onClick={() => setFilter('warehouse')}
              className={`px-6 py-2 rounded-full font-medium transition-all ${
                filter === 'warehouse' 
                  ? 'bg-blue-800 text-white' 
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Warehouse
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredSpaces.map((space) => (
            <div 
              key={space.id} 
              className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-xl transition-all duration-300"
            >
              <div className="relative">
                <img 
                  src={space.image} 
                  alt={space.title} 
                  className="w-full h-64 object-cover"
                />
                <div className="absolute top-4 right-4">
                  <span className={`text-white text-sm font-semibold px-3 py-1 rounded-full ${
                    space.availability === 'Immediate' ? 'bg-green-500' : 'bg-yellow-500'
                  }`}>
                    {space.availability}
                  </span>
                </div>
                <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/70 to-transparent p-4">
                  <span className="text-white font-medium flex items-center">
                    {space.type === 'office' && <Building size={16} className="mr-1" />}
                    {space.type === 'retail' && <Users size={16} className="mr-1" />}
                    {space.type === 'warehouse' && <Map size={16} className="mr-1" />}
                    {space.type.charAt(0).toUpperCase() + space.type.slice(1)}
                  </span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold text-gray-900 mb-2">{space.title}</h3>
                
                <div className="flex justify-between items-center mb-4">
                  <div className="text-gray-600">{space.size}</div>
                  <div className="text-blue-800 font-medium">{space.price}</div>
                </div>
                
                <ul className="mb-4">
                  {space.features.map((feature, index) => (
                    <li key={index} className="flex items-start mb-2">
                      <svg 
                        className="w-5 h-5 text-green-500 mr-2 mt-0.5" 
                        fill="none" 
                        stroke="currentColor" 
                        viewBox="0 0 24 24" 
                        xmlns="http://www.w3.org/2000/svg"
                      >
                        <path 
                          strokeLinecap="round" 
                          strokeLinejoin="round" 
                          strokeWidth="2" 
                          d="M5 13l4 4L19 7"
                        ></path>
                      </svg>
                      <span className="text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <a 
                  href="#contact" 
                  className="inline-flex items-center text-blue-800 font-semibold hover:text-blue-900 transition-colors"
                >
                  Inquire about this space
                  <ArrowUpRight size={16} className="ml-1" />
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center mt-12">
          <a 
            href="#contact" 
            className="bg-blue-800 hover:bg-blue-900 text-white font-semibold py-3 px-8 rounded-md transition-all duration-200 shadow-md hover:shadow-lg inline-block"
          >
            Schedule a Viewing
          </a>
        </div>
      </div>
    </section>
  );
};

export default Spaces;