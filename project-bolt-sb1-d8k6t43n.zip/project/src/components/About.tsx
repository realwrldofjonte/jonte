import React from 'react';
import { Building2, MapPin, Clock, Shield } from 'lucide-react';

const About: React.FC = () => {
  const features = [
    {
      icon: <Building2 size={24} className="text-blue-800" />,
      title: 'Modern Infrastructure',
      description: 'State-of-the-art facilities designed to meet the needs of modern businesses.',
    },
    {
      icon: <MapPin size={24} className="text-blue-800" />,
      title: 'Strategic Location',
      description: 'Conveniently located along Mombasa Road with easy access to major transport routes.',
    },
    {
      icon: <Clock size={24} className="text-blue-800" />,
      title: '24/7 Accessibility',
      description: 'Round-the-clock access to your workspace with secure entry systems.',
    },
    {
      icon: <Shield size={24} className="text-blue-800" />,
      title: 'Enhanced Security',
      description: 'Comprehensive security measures including CCTV surveillance and guard service.',
    },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">About Eens Business Park</h2>
          <div className="w-24 h-1 bg-yellow-500 mx-auto mb-6"></div>
          <p className="text-lg text-gray-700">
            Eens Business Park is a premier commercial development in Syokimau, offering modern office spaces and amenities designed to help businesses thrive in a professional environment.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <div 
                  key={index} 
                  className="bg-gray-50 p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow duration-300"
                >
                  <div className="mb-4">{feature.icon}</div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="order-1 md:order-2">
            <div className="relative">
              <img 
                src="https://images.pexels.com/photos/1170412/pexels-photo-1170412.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2" 
                alt="Eens Business Park Exterior" 
                className="rounded-lg shadow-xl"
              />
              <div className="absolute -bottom-6 -left-6 bg-yellow-500 text-white p-4 rounded-lg shadow-lg">
                <p className="text-lg font-semibold">Established 2023</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;