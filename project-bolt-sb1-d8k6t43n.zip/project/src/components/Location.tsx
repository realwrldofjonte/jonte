import React from 'react';
import { MapPin, Clock, Plane, Building, Car } from 'lucide-react';

const Location: React.FC = () => {
  const proximityPoints = [
    {
      icon: <Plane size={20} className="text-blue-800" />,
      point: 'JKIA Airport',
      distance: '15 min drive (10 km)',
    },
    {
      icon: <Building size={20} className="text-blue-800" />,
      point: 'Nairobi CBD',
      distance: '25 min drive (20 km)',
    },
    {
      icon: <Car size={20} className="text-blue-800" />,
      point: 'SGR Terminus',
      distance: '10 min drive (5 km)',
    },
    {
      icon: <MapPin size={20} className="text-blue-800" />,
      point: 'Syokimau Station',
      distance: '5 min drive (2 km)',
    },
  ];

  return (
    <section id="location" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 md:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">Strategic Location</h2>
          <div className="w-24 h-1 bg-yellow-500 mx-auto mb-6"></div>
          <p className="text-lg text-gray-700">
            Located in Syokimau along Mombasa Road, Eens Business Park offers unparalleled accessibility and convenience.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          <div className="bg-white p-8 rounded-lg shadow-md">
            <h3 className="text-2xl font-semibold text-gray-900 mb-6">Why Our Location Matters</h3>
            
            <div className="mb-8">
              <h4 className="text-xl font-medium text-blue-800 mb-3 flex items-center">
                <MapPin size={20} className="mr-2" />
                Prime Position
              </h4>
              <p className="text-gray-700 ml-7">
                Strategically situated along the busy Mombasa Road corridor, providing excellent visibility and accessibility for your business.
              </p>
            </div>
            
            <div className="mb-8">
              <h4 className="text-xl font-medium text-blue-800 mb-3 flex items-center">
                <Clock size={20} className="mr-2" />
                Reduced Commute Times
              </h4>
              <p className="text-gray-700 ml-7">
                Beat the notorious Nairobi traffic with a location that allows your employees to avoid the worst congestion points of the city.
              </p>
            </div>
            
            <div>
              <h4 className="text-xl font-medium text-blue-800 mb-3">Proximity To Key Points</h4>
              <ul className="space-y-3">
                {proximityPoints.map((item, index) => (
                  <li key={index} className="flex items-center">
                    <div className="mr-3">{item.icon}</div>
                    <div>
                      <span className="font-medium">{item.point}:</span> {item.distance}
                    </div>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          
          <div className="h-full min-h-[400px] rounded-lg overflow-hidden shadow-md">
            <iframe 
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15955.256767964522!2d36.91272073809958!3d-1.371237407563749!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x182f05ef03d1b775%3A0x71c77cfb595255b3!2sSyokimau%2C%20Machakos%20County!5e0!3m2!1sen!2ske!4v1696889540547!5m2!1sen!2ske" 
              width="100%" 
              height="100%" 
              style={{ border: 0 }} 
              allowFullScreen={true} 
              loading="lazy" 
              referrerPolicy="no-referrer-when-downgrade"
              title="Eens Business Park Location"
            ></iframe>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Location;