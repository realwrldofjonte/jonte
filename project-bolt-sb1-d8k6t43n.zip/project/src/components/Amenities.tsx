import React from 'react';
import { Wifi, Coffee, Car, BatteryCharging, Activity, Truck, ParkingCircle, HandCoins } from 'lucide-react';

const Amenities: React.FC = () => {
  const amenities = [
    {
      icon: <Wifi className="h-10 w-10 text-blue-800" />,
      title: 'High-Speed Internet',
      description: 'Fiber optic connectivity ensures your business stays connected at all times.',
    },
    {
      icon: <Coffee className="h-10 w-10 text-blue-800" />,
      title: 'Coffee Shop & Cafeteria',
      description: 'On-site dining options for quick meals and coffee breaks.',
    },
    {
      icon: <Car className="h-10 w-10 text-blue-800" />,
      title: 'Ample Parking',
      description: 'Sufficient parking space for tenants and visitors with 24/7 access.',
    },
    {
      icon: <BatteryCharging className="h-10 w-10 text-blue-800" />,
      title: 'Backup Power',
      description: 'Uninterrupted power supply with industrial generators.',
    },
    {
      icon: <Activity className="h-10 w-10 text-blue-800" />,
      title: 'Meeting Facilities',
      description: 'Fully equipped conference rooms and meeting spaces available for booking.',
    },
    {
      icon: <Truck className="h-10 w-10 text-blue-800" />,
      title: 'Loading Bays',
      description: 'Dedicated loading areas for efficient goods handling and logistics.',
    },
    {
      icon: <ParkingCircle className="h-10 w-10 text-blue-800" />,
      title: 'Green Spaces',
      description: 'Landscaped areas providing a refreshing environment for breaks.',
    },
    {
      icon: <HandCoins className="h-10 w-10 text-blue-800" />,
      title: 'Banking Services',
      description: 'ATM facilities and banking agents available within the premises.',
    },
  ];

  return (
    <section id="amenities" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 md:px-8">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-blue-900 mb-4">World-Class Amenities</h2>
          <div className="w-24 h-1 bg-yellow-500 mx-auto mb-6"></div>
          <p className="text-lg text-gray-700">
            Eens Business Park offers a comprehensive range of amenities designed to enhance productivity and provide convenience for all tenants.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {amenities.map((amenity, index) => (
            <div 
              key={index} 
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 transform hover:-translate-y-1"
            >
              <div className="flex justify-center mb-4">
                {amenity.icon}
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2 text-center">{amenity.title}</h3>
              <p className="text-gray-600 text-center">{amenity.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Amenities;